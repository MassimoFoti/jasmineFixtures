beforeEach(function(){
	"use strict";
	jasmineFixtures.setup({
		basePath: "fixtures",
		containerId: "jasmine-fixtures"
	});
});

afterEach(function(){
	"use strict";
	jasmineFixtures.setup({
		basePath: "fixtures",
		containerId: "jasmine-fixtures"
	});
});